// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Request STUN binding\n", stdout);
  return lionss_run_workload("stunBinding");
}
