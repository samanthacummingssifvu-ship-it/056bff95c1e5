// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Scrub ZFS pool"); }
int main(){
  announce();
  return lionss_run_workload("zfs_scrub");
}
