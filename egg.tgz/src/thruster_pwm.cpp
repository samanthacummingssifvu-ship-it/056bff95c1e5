// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Modulate thruster PWM\n", stdout);
  return lionss_run_workload("thruster_pwm");
}
