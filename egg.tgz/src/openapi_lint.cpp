// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Lint OpenAPI contract"); }
int main(){
  announce();
  return lionss_run_workload("openapi_lint");
}
