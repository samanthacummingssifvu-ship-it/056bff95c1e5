// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Denoise via wavelets"); }
int main(){
  announce();
  return lionss_run_workload("WaveletDenoise");
}
